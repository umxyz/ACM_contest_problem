#include <cstdio>
#include <memory.h>
#define N 30001
#define M 100000
int n, k, a, b, hd[N], to[M], ne[M], le[M], sz = 0;
void addedge(int x, int y, int v) {
    ne[sz] = hd[x];
    le[sz] = v;
    to[sz] = y;
    hd[x] = sz;
    sz++;
}
int dis[N], que[N], tail, head;
bool vis[N];
void spfa(int s) {
	head = 0; tail = 1;
	memset(vis, 0, sizeof(vis));
	memset(dis, 80, sizeof(dis));
	que[0] = s; dis[s] = 0;
	while (tail != head) {
        int u = que[head++];
        if (head == N) head = 0;
        vis[u] = 0;
        for (int e = hd[u]; e != -1; e = ne[e]) {
            int v = to[e];
            if (dis[v] > dis[u] + le[e]) {
                dis[v] = dis[u] + le[e];
                if (!vis[v]) {
                    vis[v] = 1;
                    que[tail++] = v;
                    if (tail == N) tail = 0;
                }
            }
        }
    }
}
int main() {
    scanf("%d%d", &n, &k);
	memset(hd, -1, sizeof(hd));
    for (int i = 1; i <= n; i++) {
        addedge(i-1, i, k);
        addedge(i, i-1, 0);
    }
	scanf("%d", &a);
    while (a--) {
        int x, y, v;
        scanf("%d%d%d", &x, &y, &v);
        addedge(x-1, y, v);
    }
	scanf("%d", &b);
    while (b--) {
        int x, y, v;
        scanf("%d%d%d", &x, &y, &v);
        addedge(y, x-1, -v);
    }
    spfa(0);
    printf("%d\n", dis[n]);
	spfa(n);
    printf("%d\n", -dis[0]);
}