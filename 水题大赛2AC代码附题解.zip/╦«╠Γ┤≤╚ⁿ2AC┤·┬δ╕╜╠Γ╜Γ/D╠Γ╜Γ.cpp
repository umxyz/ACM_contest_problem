#include<cstdio>
#include<queue>
int k,m;
int a;
std::priority_queue<int> w,s;
int cnt;
int main(){
	scanf("%d",&k);
	for(int i=1;i<=4;i++){
		scanf("%d",&a);
		w.push(a);
		w.push(a);
	}
	scanf("%d",&m);
	for(int i=1;i<=4;i++){
		scanf("%d",&a);
		s.push(a);
		s.push(a);
	}
	while(w.size()){
		m-=w.top();
		w.pop();
		cnt++;
		if(k<=0 || m<=0) break;
		k-=s.top();
		s.pop();
		if(k<=0 || m<=0) break;
	}
	if(k<=0 || m>0){
		puts("-1");
		return 0;
	}
	printf("%d",cnt);
	return 0;
}
