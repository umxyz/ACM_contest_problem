#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;
int n;
long long a[20005],b[20005],k[2];
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		memset(a,0,sizeof(a));
		int j=0;
		cin>>n;
		for(int i=1;i<=n;i++)
		{
			cin>>a[i];
		}
		sort(a+1,a+n+1);
		for(int i=1;i<=n;i++)
		{
			if(a[i]!=a[i-1] && a[i]!=a[i+1])
			{
				k[j]=a[i];
				j++;
		    }
		}
		cout<<k[0]<<" "<<k[1]<<endl;
	}
	return 0;
}
