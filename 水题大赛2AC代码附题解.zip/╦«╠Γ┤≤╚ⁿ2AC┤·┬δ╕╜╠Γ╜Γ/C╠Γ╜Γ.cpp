#include <cstdio>
#include <memory.h>
#define N 10000
#define M 30001
int hd[2][N] = {0}, to[2][M], ne[2][M], le[M], n, m, s, t;
int dis[2][N], que[N]; bool inq[N] = {0};
void bfs(int s, bool go) {
    int head = 0, tail = 1;
    que[0] = s; dis[go][s] = 0;
    while (head != tail) {
        int u = que[head++];
        inq[u] = false;
        for (int e = hd[go][u]; e; e = ne[go][e]) {
            int v = to[go][e];
            if (dis[go][v] > dis[go][u] + le[e]) {
                dis[go][v] = dis[go][u] + le[e];
                if (!inq[v]) {
                    inq[v] = true;
                    que[tail++] = v;
                }
            }
        }
    }
}
int main() {
    scanf("%d%d%d%d", &n, &m, &s, &t);
	memset(dis, 0x33, sizeof(dis));
    for (int i = 1; i <= m; i++) {
        int u, v, l;
        scanf("%d%d%d", &u, &v, &l);
        to[0][i] = v;
        ne[0][i] = hd[0][u];
        hd[0][u] = i;
		to[1][i] = u;
        ne[1][i] = hd[1][v];
        hd[1][v] = i;
		le[i] = l;
    }
    bfs(s, 0); bfs(t, 1);
	int ans = 100000000;
    for (int i = 1; i <= m; i++) {
		int nt = dis[0][to[1][i]] + dis[1][to[0][i]];
		if (nt < ans) ans = nt;
		nt = dis[0][to[0][i]] + dis[1][to[1][i]];
		if (nt < ans) ans = nt;
	}
    printf("%d", ans);
}