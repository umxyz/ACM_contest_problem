#include <iostream>
int main() {
    long long n;
	std::cin >> n;
	std::cout << 3*n/2;
}