cd ../../problems/kd-tree-subroutine/statements/english
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/odd-discount/statements/english
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/queen-dominating-set-count/statements/english
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/set-longest-common-subsequence/statements/english
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/knapsack-123/statements/english
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/sparse-graph-shortest-path-query/statements/english
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/square-connectivity/statements/english
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/tree-eulerian-cycle-count/statements/english
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/lis-5-count/statements/english
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/matrix-shift/statements/english
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
