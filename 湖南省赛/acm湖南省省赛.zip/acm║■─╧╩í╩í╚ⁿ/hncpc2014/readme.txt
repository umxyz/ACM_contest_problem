A: geometry
B: bitmask dp
C: ...
D: mincost flow
E: ...
F: brute-force + bicoloring
G: tree dp
H: linear dp
I: if(simpler) or bfs(safer)
J: interval tree of persistent bst
K: recursion

by Rujia Liu
